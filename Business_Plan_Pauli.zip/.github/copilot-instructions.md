# Instruções para AI Coding Agents - Business Plan Escolar

## 📋 Visão Geral do Projeto

**Propósito**: Sistema web para análise de viabilidade financeira de implantação de aulas extracurriculares em escolas, com objetivo de aumentar matrículas em 30-50%.

**Stack Principal**: Python 3.x + Flask + SQLite + Bootstrap 5 + Chart.js

## 🏗️ Arquitetura e Estrutura

### Layout do Projeto
```
Business_Plan_Pauli/
├── app.py                 # Aplicação Flask principal (318 linhas)
├── setup.py              # Script de inicialização do ambiente
├── requirements.txt      # Dependências (Flask==2.3.3, Flask-SQLAlchemy==3.0.5)
├── data/                 # Banco de dados SQLite (database.db)
├── static/
│   ├── css/style.css    # Estilos customizados
│   └── js/charts.js     # Gráficos e interatividade
└── templates/
    ├── base.html        # Template base com navbar (Bootstrap 5)
    ├── index.html       # Página inicial
    ├── simulacao.html   # Formulário de entrada de dados
    ├── resultado.html   # Exibição dos cálculos
    └── dashboard.html   # Histórico e comparação de simulações
```

### Fluxo de Dados Principal
1. **Entrada**: Usuário preence formulário em `simulacao.html` (alunos, custos, etc)
2. **Processamento**: POST para `/calcular` → `calcular_projecao()` realiza cálculos financeiros
3. **Persistência**: Dados salvos em SQLite via `salvar_simulacao()`
4. **Visualização**: Resultado em `resultado.html` + histórico em `/dashboard`

## 🔧 Convenções e Padrões do Projeto

### Funções Críticas em `app.py`

- **`calcular_projecao(dados)`**: Coração dos cálculos. Entradas são dicionário com chaves:
  - `alunos_atuais`, `mensalidade_media`, `aumento_esperado` (%)
  - `custo_infraestrutura`, `custo_material`, `custo_marketing`
  - `num_atividades`, `custo_professor_por_hora`, `horas_semanais`
  
  Retorna dicionário com `roi_percentual`, `payback_meses`, `investimento_total`, etc.

- **`init_db()`**: Criação automática de tabela `simulacoes` na primeira execução

- **`salvar_simulacao(dados_entrada, resultados)`**: Persiste em SQLite; note campo `dados` em JSON para histórico completo

### Validações de Negócio
```python
# Em /calcular (linha ~215)
aumento_esperado deve estar entre 30% e 50%  # Requisito core
alunos_atuais > 0                             # Validação básica
```

### Cálculos Financeiros Principais
- **Payback**: `investimento_total / retorno_mensal` (em meses)
- **ROI**: `(retorno_mensal * 12 / investimento_total) * 100` (%)
- **Retorno Mensal**: `novos_alunos * mensalidade_media`
- **Custo Professores**: `num_atividades * custo_hora * horas_semanais * 4.3`

## 🚀 Workflow de Desenvolvimento

### Inicializar Ambiente
```bash
python setup.py           # Cria pastas e estrutura
pip install -r requirements.txt
python app.py            # Inicia Flask em http://localhost:5000
```

### Testes e Debugging
- **Session Storage**: Resultados armazenados em `session['ultima_simulacao']` para redirecionamentos
- **Banco de Dados**: SQLite em `data/database.db` — reiniciável deletando arquivo
- **Debug Mode**: `app.run(debug=True)` habilitado por padrão em `app.py`

### Rotas Principais
| Rota | Método | Propósito |
|------|--------|----------|
| `/` | GET | Página inicial |
| `/simulacao` | GET | Formulário de entrada |
| `/calcular` | POST | Processa cálculos (retorna JSON) |
| `/resultado` | GET | Exibe resultado (usa sessão) |
| `/dashboard` | GET | Lista histórico de simulações |
| `/api/simulacoes` | GET | JSON de todas simulações |

## 💡 Padrões Específicos do Projeto

### Session vs Database
- **Session**: `ultima_simulacao` — armazenam resultado temporário para exibição em `/resultado`
- **Database**: Todos os cálculos também persistem em `simulacoes` para dashboard

### Formatação de Datas
- Entrada no banco: `strftime('%Y-%m-%d %H:%M:%S')`
- Leitura e formatação: use `datetime.strptime()` (linha ~275 em dashboard)

### Estrutura de Resposta da API
```json
{
  "novos_alunos": int,
  "receita_atual": float,
  "receita_projetada": float,
  "investimento_total": float,
  "retorno_mensal": float,
  "payback_meses": float,
  "roi_percentual": float,
  "custo_professores": float,
  "custo_infraestrutura": float,
  "custo_material": float,
  "custo_marketing": float
}
```

## 🎨 Frontend Conventions

### Dependências Externas
- **Bootstrap 5.1.3**: CDN (navbar, forms, grid)
- **Font Awesome 6.0.0**: Ícones (e.g., `<i class="fas fa-chart-line"></i>`)
- **Chart.js**: Gráficos (CDN, arquivo local vazio — verifique `templates/`)

### Idioma e Localização
- Toda UI em **português brasileiro** (pt-BR)
- Moedas em BRL, formato numérico brasileiro (onde aplicável)

## ⚠️ Pontos de Atenção

1. **Pasta `data/` gerada dinamicamente**: Nunca assuma sua existência — `init_db()` cria se necessário
2. **SQLite é single-file**: Sem migrations formais — atualizações requerem ALTER TABLE manual se mudarem schema
3. **Secret key hardcoded**: Em produção, use variáveis de ambiente (`os.environ`)
4. **Charts.js file vazio**: Gráficos renderizados via JavaScript inline em templates ou completar `static/js/charts.js`
5. **Validação fraca**: Adicionar mais validações além de `aumento_esperado` se expandir campos

## 📝 Próximos Passos Típicos

- **Adicionar campos**: Atualizar `calcular_projecao()` → schema SQLite → endpoints → templates
- **Melhorar gráficos**: Completar `charts.js` com Chart.js instâncias para `/resultado` e `/dashboard`
- **Autenticação**: Adicionar controle de usuário (não presente atualmente)
- **Relatórios PDF**: Integrar biblioteca para exportar simulações
