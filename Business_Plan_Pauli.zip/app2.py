from flask import Flask, render_template_string, request, jsonify, session, redirect
from datetime import datetime
import json
import math
import os
import sqlite3

app = Flask(__name__)

# Configuração para produção
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'business_plan_escolar_prod_2024_seguro')
app.config['TEMPLATES_AUTO_RELOAD'] = os.environ.get('FLASK_ENV') == 'development'
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 31536000

# Configuração do banco de dados
basedir = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(basedir, 'data', 'database.db')

# Dados de custos específicos SIMPLIFICADOS
CUSTOS_POR_NIVEL = {
    'infantil': {
        'nome': 'Educação Infantil',
        'cor': '#FF6B8B',
        'custo_professor_hora': 45,
        'ratio': 8,
        'custos_fixos': [
            {'nome': 'Brinquedoteca', 'valor': 5000},
            {'nome': 'Adaptação salas', 'valor': 3000}
        ]
    },
    'fundamental_i': {
        'nome': 'Fundamental I',
        'cor': '#4ECDC4',
        'custo_professor_hora': 50,
        'ratio': 15,
        'custos_fixos': [
            {'nome': 'Laboratório informática', 'valor': 8000},
            {'nome': 'Biblioteca infantil', 'valor': 4000}
        ]
    },
    'fundamental_ii': {
        'nome': 'Fundamental II',
        'cor': '#45B7D1',
        'custo_professor_hora': 55,
        'ratio': 20,
        'custos_fixos': [
            {'nome': 'Laboratório ciências', 'valor': 12000},
            {'nome': 'Equipamento robótica', 'valor': 10000}
        ]
    },
    'medio': {
        'nome': 'Ensino Médio',
        'cor': '#96CEB4',
        'custo_professor_hora': 65,
        'ratio': 25,
        'custos_fixos': [
            {'nome': 'Laboratório química', 'valor': 15000},
            {'nome': 'Plataforma ensino', 'valor': 8000}
        ]
    }
}

def init_db():
    """Inicializa o banco de dados SQLite"""
    try:
        data_dir = os.path.join(basedir, 'data')
        if not os.path.exists(data_dir):
            os.makedirs(data_dir, exist_ok=True)
        
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS simulacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            data_criacao TEXT,
            alunos_atuais INTEGER,
            mensalidade_media REAL,
            aumento_esperado REAL,
            novos_alunos INTEGER,
            nivel_escolar TEXT,
            investimento_total REAL,
            retorno_mensal REAL,
            payback REAL,
            roi REAL,
            dados TEXT
        )
        ''')
        
        conn.commit()
        conn.close()
        print("✅ Banco de dados inicializado com sucesso!")
        return True
    except Exception as e:
        print(f"❌ Erro ao inicializar banco de dados: {e}")
        return False

def salvar_simulacao(dados_entrada, resultados):
    """Salva uma simulação no banco de dados"""
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        cursor.execute('''
        INSERT INTO simulacoes (
            nome, data_criacao, alunos_atuais, mensalidade_media,
            aumento_esperado, novos_alunos, nivel_escolar,
            investimento_total, retorno_mensal, payback, roi, dados
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            f"Simulação {datetime.now().strftime('%d/%m/%Y %H:%M')}",
            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            dados_entrada.get('alunos_atuais', 0),
            dados_entrada.get('mensalidade_media', 0),
            dados_entrada.get('aumento_esperado', 0),
            resultados.get('novos_alunos', 0),
            dados_entrada.get('nivel_escolar', 'fundamental_i'),
            resultados.get('investimento_total', 0),
            resultados.get('retorno_mensal', 0),
            resultados.get('payback_meses', 0),
            resultados.get('roi_percentual', 0),
            json.dumps({'entrada': dados_entrada, 'resultados': resultados})
        ))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Erro ao salvar simulação: {e}")
        return False

def buscar_simulacoes():
    """Busca todas as simulações do banco de dados"""
    try:
        conn = sqlite3.connect(DATABASE)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM simulacoes ORDER BY data_criacao DESC')
        simulacoes = cursor.fetchall()
        
        conn.close()
        return simulacoes
    except Exception as e:
        print(f"Erro ao buscar simulações: {e}")
        return []

# Função de cálculo SIMPLIFICADA
def calcular_projecao(dados):
    """Calcula todas as projeções baseadas nos dados inseridos"""
    
    alunos_atuais = dados.get('alunos_atuais', 0)
    mensalidade = dados.get('mensalidade_media', 0)
    aumento_percentual = dados.get('aumento_esperado', 0) / 100
    
    # Cálculo de novos alunos
    novos_alunos = int(alunos_atuais * aumento_percentual)
    total_alunos = alunos_atuais + novos_alunos
    
    # Receitas
    receita_atual = alunos_atuais * mensalidade
    receita_projetada = total_alunos * mensalidade
    
    # Configurações do nível escolar
    nivel = dados.get('nivel_escolar', 'fundamental_i')
    config = CUSTOS_POR_NIVEL.get(nivel, CUSTOS_POR_NIVEL['fundamental_i'])
    
    # Cálculo de professores necessários
    professores_necessarios = math.ceil(total_alunos / config['ratio'])
    horas_semanais = dados.get('horas_semanais', 10)
    semanas_mes = 4.3
    custo_professores = professores_necessarios * config['custo_professor_hora'] * horas_semanais * semanas_mes
    
    # Custos fixos do nível
    custos_fixos_total = sum(item['valor'] for item in config['custos_fixos'])
    
    # Custos variáveis do usuário
    custo_infra = dados.get('custo_infraestrutura', 1000)
    custo_material = dados.get('custo_material', 500)
    custo_marketing = dados.get('custo_marketing', 800)
    
    # Investimento total
    investimento_total = custo_professores + custos_fixos_total + custo_infra + custo_material + custo_marketing
    
    # Retorno mensal adicional
    retorno_mensal = novos_alunos * mensalidade
    
    # Cálculo de payback e ROI
    payback_meses = investimento_total / retorno_mensal if retorno_mensal > 0 else 0
    roi_percentual = (retorno_mensal * 12 / investimento_total * 100) if investimento_total > 0 else 0
    
    return {
        'novos_alunos': novos_alunos,
        'receita_atual': receita_atual,
        'receita_projetada': receita_projetada,
        'investimento_total': investimento_total,
        'retorno_mensal': retorno_mensal,
        'payback_meses': payback_meses,
        'roi_percentual': roi_percentual,
        'professores_necessarios': professores_necessarios,
        'custo_professores': custo_professores,
        'custos_fixos_total': custos_fixos_total,
        'nivel': nivel,
        'nome_nivel': config['nome'],
        'cor_nivel': config['cor'],
        'custos_fixos': config['custos_fixos']
    }

# Template HTML base SIMPLIFICADO
def get_base_html(title="Business Plan Escolar", content=""):
    return f'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {{
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }}
        .navbar-brand {{
            font-weight: 700;
        }}
        .card {{
            border-radius: 10px;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }}
        .btn-primary {{
            background-color: #4361ee;
            border-color: #4361ee;
        }}
        .btn-success {{
            background-color: #28a745;
            border-color: #28a745;
        }}
        .form-control:focus {{
            border-color: #4361ee;
            box-shadow: 0 0 0 0.2rem rgba(67, 97, 238, 0.25);
        }}
        .nivel-card {{
            cursor: pointer;
            transition: all 0.3s;
            border: 2px solid transparent;
        }}
        .nivel-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }}
        .nivel-card.selected {{
            border-color: #4361ee;
            background-color: #f0f4ff;
        }}
        .badge-nivel {{
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8em;
            font-weight: 600;
        }}
        footer {{
            background-color: #2c3e50;
            color: white;
            padding: 20px 0;
            margin-top: 40px;
        }}
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="fas fa-chart-line"></i> Business Plan Escolar
            </a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/">Início</a></li>
                    <li class="nav-item"><a class="nav-link" href="/simulacao">Simulação</a></li>
                    <li class="nav-item"><a class="nav-link" href="/dashboard">Dashboard</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        {content}
    </div>

    <footer class="bg-dark text-white mt-5">
        <div class="container text-center">
            <p>Sistema de Business Plan para Escolas © 2024</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>'''

# Rotas SIMPLIFICADAS
@app.route('/')
def index():
    content = '''
    <div class="row">
        <div class="col-lg-8 mx-auto text-center">
            <div class="card bg-primary text-white mb-5">
                <div class="card-body py-5">
                    <h1 class="display-4 mb-3">
                        <i class="fas fa-school"></i> Business Plan Escolar
                    </h1>
                    <p class="lead mb-4">
                        Sistema de análise para expansão com aulas extracurriculares
                    </p>
                    <a href="/simulacao" class="btn btn-light btn-lg">
                        <i class="fas fa-play-circle"></i> Iniciar Nova Simulação
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-calculator fa-3x text-primary mb-3"></i>
                    <h4>Cálculos Automáticos</h4>
                    <p>ROI, Payback, Investimento e Retorno</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-chart-line fa-3x text-success mb-3"></i>
                    <h4>Análise por Nível</h4>
                    <p>Custos específicos por faixa etária</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-file-alt fa-3x text-info mb-3"></i>
                    <h4>Relatórios Completos</h4>
                    <p>Dashboard e histórico de simulações</p>
                </div>
            </div>
        </div>
    </div>
    '''
    return get_base_html("Business Plan Escolar - Início", content)

@app.route('/simulacao')
def simulacao():
    content = '''
    <div class="row">
        <div class="col-lg-10 mx-auto">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0"><i class="fas fa-calculator"></i> Simulação de Business Plan</h3>
                </div>
                <div class="card-body">
                    <!-- Passo 1: Seleção do Nível -->
                    <div id="passo1">
                        <h4 class="mb-4">1. Selecione o Nível Escolar</h4>
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="card nivel-card text-center" onclick="selecionarNivel('infantil')">
                                    <div class="card-body">
                                        <i class="fas fa-baby fa-3x mb-3" style="color: #FF6B8B;"></i>
                                        <h5>Educação Infantil</h5>
                                        <small>Berçário ao infantil</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card nivel-card text-center" onclick="selecionarNivel('fundamental_i')">
                                    <div class="card-body">
                                        <i class="fas fa-child fa-3x mb-3" style="color: #4ECDC4;"></i>
                                        <h5>Fundamental I</h5>
                                        <small>1º ao 5º ano</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card nivel-card text-center" onclick="selecionarNivel('fundamental_ii')">
                                    <div class="card-body">
                                        <i class="fas fa-user-graduate fa-3x mb-3" style="color: #45B7D1;"></i>
                                        <h5>Fundamental II</h5>
                                        <small>6º ao 9º ano</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card nivel-card text-center" onclick="selecionarNivel('medio')">
                                    <div class="card-body">
                                        <i class="fas fa-university fa-3x mb-3" style="color: #96CEB4;"></i>
                                        <h5>Ensino Médio</h5>
                                        <small>Preparação ENEM</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="nivel_escolar" value="">
                    </div>

                    <!-- Passo 2: Dados da Escola (aparece após selecionar nível) -->
                    <div id="passo2" style="display: none;">
                        <h4 class="mb-4">2. Dados da Escola</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Número atual de alunos:</label>
                                    <input type="number" class="form-control" id="alunos_atuais" value="200" min="1">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Mensalidade média (R$):</label>
                                    <input type="number" class="form-control" id="mensalidade_media" value="800" min="100">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Aumento esperado (%):</label>
                                    <div class="input-group">
                                        <input type="range" class="form-range" id="aumento_range" min="30" max="50" step="5" value="40">
                                        <span class="input-group-text" id="aumento_value">40%</span>
                                    </div>
                                    <input type="hidden" id="aumento_esperado" value="40">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Horas semanais de atividades:</label>
                                    <input type="number" class="form-control" id="horas_semanais" value="10" min="5">
                                </div>
                            </div>
                        </div>
                        
                        <div id="info_nivel" class="alert alert-info" style="display: none;">
                            <i class="fas fa-info-circle"></i>
                            <span id="texto_nivel"></span>
                        </div>
                    </div>

                    <!-- Passo 3: Custos (aparece após preencher dados) -->
                    <div id="passo3" style="display: none;">
                        <h4 class="mb-4">3. Custos do Projeto</h4>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Infraestrutura (R$):</label>
                                    <input type="number" class="form-control" id="custo_infraestrutura" value="1000" min="0">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Material (R$):</label>
                                    <input type="number" class="form-control" id="custo_material" value="500" min="0">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Marketing (R$):</label>
                                    <input type="number" class="form-control" id="custo_marketing" value="800" min="0">
                                </div>
                            </div>
                        </div>
                        
                        <div id="custos_nivel" class="card mb-3" style="display: none;">
                            <div class="card-header">
                                <h6 class="mb-0">Custos específicos do nível:</h6>
                            </div>
                            <div class="card-body">
                                <div id="lista_custos_nivel"></div>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i>
                            Todos os valores são editáveis. Ajuste conforme sua realidade.
                        </div>
                    </div>

                    <!-- Botões de navegação -->
                    <div class="row mt-4">
                        <div class="col-12 text-center">
                            <button id="btnProximo" class="btn btn-primary btn-lg" onclick="proximoPasso()" disabled>
                                <i class="fas fa-arrow-right"></i> Próximo
                            </button>
                            <button id="btnCalcular" class="btn btn-success btn-lg" onclick="calcularSimulacao()" style="display: none;">
                                <i class="fas fa-calculator"></i> Calcular e Salvar
                            </button>
                            <button class="btn btn-secondary btn-lg" onclick="reiniciarSimulacao()">
                                <i class="fas fa-redo"></i> Reiniciar
                            </button>
                        </div>
                    </div>

                    <!-- Resultado -->
                    <div id="resultado" class="mt-4" style="display: none;"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
    let passoAtual = 1;
    let nivelSelecionado = '';
    let dadosNivel = {};

    // Dados dos níveis
    const niveis = ''' + json.dumps(CUSTOS_POR_NIVEL) + ''';

    function selecionarNivel(nivel) {
        // Remover seleção anterior
        document.querySelectorAll('.nivel-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        // Selecionar novo
        const card = event.currentTarget;
        card.classList.add('selected');
        
        nivelSelecionado = nivel;
        dadosNivel = niveis[nivel] || {};
        document.getElementById('nivel_escolar').value = nivel;
        
        // Habilitar botão próximo
        document.getElementById('btnProximo').disabled = false;
        
        // Mostrar informações do nível
        document.getElementById('info_nivel').style.display = 'block';
        document.getElementById('texto_nivel').innerHTML = 
            `<strong>${dadosNivel.nome}</strong> | Custo professor/hora: R$ ${dadosNivel.custo_professor_hora} | Ratio: 1 professor para ${dadosNivel.ratio} alunos`;
        
        // Atualizar custos do nível
        if (dadosNivel.custos_fixos) {
            let html = '<ul class="mb-0">';
            dadosNivel.custos_fixos.forEach(item => {
                html += `<li>${item.nome}: R$ ${item.valor.toLocaleString('pt-BR')}</li>`;
            });
            html += '</ul>';
            document.getElementById('lista_custos_nivel').innerHTML = html;
            document.getElementById('custos_nivel').style.display = 'block';
        }
    }

    function proximoPasso() {
        if (passoAtual === 1 && !nivelSelecionado) {
            alert('Por favor, selecione um nível escolar');
            return;
        }
        
        if (passoAtual === 2) {
            // Validar dados básicos
            const alunos = document.getElementById('alunos_atuais').value;
            const mensalidade = document.getElementById('mensalidade_media').value;
            
            if (!alunos || alunos < 1) {
                alert('Informe o número de alunos');
                return;
            }
            if (!mensalidade || mensalidade < 100) {
                alert('Informe a mensalidade média');
                return;
            }
        }
        
        // Esconder passo atual
        document.getElementById('passo' + passoAtual).style.display = 'none';
        
        // Avançar para próximo passo
        passoAtual++;
        
        // Mostrar próximo passo
        document.getElementById('passo' + passoAtual).style.display = 'block';
        
        // Atualizar botões
        if (passoAtual === 3) {
            document.getElementById('btnProximo').style.display = 'none';
            document.getElementById('btnCalcular').style.display = 'inline-block';
        }
        
        // Atualizar cálculos parciais
        atualizarCalculosParciais();
    }

    function atualizarCalculosParciais() {
        if (!nivelSelecionado || passoAtual < 2) return;
        
        const alunos = parseInt(document.getElementById('alunos_atuais').value) || 0;
        const mensalidade = parseFloat(document.getElementById('mensalidade_media').value) || 0;
        const aumento = parseInt(document.getElementById('aumento_esperado').value) || 0;
        
        // Atualizar valor do aumento no range
        document.getElementById('aumento_value').textContent = aumento + '%';
        
        // Calcular novos alunos
        const novosAlunos = Math.round(alunos * (aumento / 100));
        
        // Calcular receita adicional
        const receitaAdicional = novosAlunos * mensalidade;
        
        // Mostrar preview
        const preview = document.getElementById('info_nivel');
        if (preview.style.display !== 'none') {
            preview.innerHTML = `
                <i class="fas fa-chart-line"></i>
                <strong>${dadosNivel.nome}</strong> | 
                Novos alunos: <strong>${novosAlunos}</strong> | 
                Receita adicional: <strong>R$ ${receitaAdicional.toLocaleString('pt-BR')}/mês</strong>
            `;
        }
    }

    function reiniciarSimulacao() {
        passoAtual = 1;
        nivelSelecionado = '';
        dadosNivel = {};
        
        // Mostrar passo 1
        document.getElementById('passo1').style.display = 'block';
        document.getElementById('passo2').style.display = 'none';
        document.getElementById('passo3').style.display = 'none';
        
        // Resetar botões
        document.getElementById('btnProximo').style.display = 'inline-block';
        document.getElementById('btnProximo').disabled = true;
        document.getElementById('btnCalcular').style.display = 'none';
        
        // Resetar seleção
        document.querySelectorAll('.nivel-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        // Resetar resultado
        document.getElementById('resultado').style.display = 'none';
        
        // Resetar formulários
        document.getElementById('nivel_escolar').value = '';
        document.getElementById('info_nivel').style.display = 'none';
        document.getElementById('custos_nivel').style.display = 'none';
    }

    async function calcularSimulacao() {
        // Coletar dados
        const dados = {
            nivel_escolar: nivelSelecionado,
            alunos_atuais: parseInt(document.getElementById('alunos_atuais').value),
            mensalidade_media: parseFloat(document.getElementById('mensalidade_media').value),
            aumento_esperado: parseInt(document.getElementById('aumento_esperado').value),
            horas_semanais: parseInt(document.getElementById('horas_semanais').value) || 10,
            custo_infraestrutura: parseFloat(document.getElementById('custo_infraestrutura').value) || 0,
            custo_material: parseFloat(document.getElementById('custo_material').value) || 0,
            custo_marketing: parseFloat(document.getElementById('custo_marketing').value) || 0
        };

        // Validar
        if (!dados.alunos_atuais || dados.alunos_atuais < 1) {
            alert('Informe o número de alunos');
            return;
        }
        
        if (!dados.mensalidade_media || dados.mensalidade_media < 100) {
            alert('Informe a mensalidade média');
            return;
        }

        // Desabilitar botão durante cálculo
        const btn = document.getElementById('btnCalcular');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Calculando...';
        btn.disabled = true;

        try {
            const response = await fetch('/calcular', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(dados)
            });

            const resultados = await response.json();

            if (response.ok) {
                mostrarResultados(resultados);
                // Salvar automaticamente - a API já salva no banco
                setTimeout(() => {
                    window.location.href = '/resultado';
                }, 2000);
            } else {
                alert('Erro: ' + (resultados.error || 'Desconhecido'));
            }
        } catch (error) {
            alert('Erro ao calcular: ' + error.message);
        } finally {
            btn.innerHTML = '<i class="fas fa-calculator"></i> Calcular e Salvar';
            btn.disabled = false;
        }
    }

    function mostrarResultados(resultados) {
        const divResultado = document.getElementById('resultado');
        
        let html = `
            <div class="card border-success">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0"><i class="fas fa-check-circle"></i> Simulação Calculada!</h4>
                </div>
                <div class="card-body">
                    <div class="alert alert-success">
                        <h5><i class="fas fa-chart-line"></i> Resultados Principais</h5>
                        <p>Redirecionando para análise detalhada...</p>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr><th>Investimento Total:</th><td class="text-danger">R$ ${resultados.investimento_total.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</td></tr>
                                <tr><th>Retorno Mensal:</th><td class="text-success">R$ ${resultados.retorno_mensal.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</td></tr>
                                <tr><th>Payback:</th><td>${resultados.payback_meses.toFixed(1)} meses</td></tr>
                                <tr><th>ROI Anual:</th><td class="text-success">${resultados.roi_percentual.toFixed(1)}%</td></tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr><th>Novos Alunos:</th><td>${resultados.novos_alunos}</td></tr>
                                <tr><th>Professores:</th><td>${resultados.professores_necessarios}</td></tr>
                                <tr><th>Receita Atual:</th><td>R$ ${resultados.receita_atual.toLocaleString('pt-BR')}</td></tr>
                                <tr><th>Receita Projetada:</th><td>R$ ${resultados.receita_projetada.toLocaleString('pt-BR')}</td></tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        divResultado.innerHTML = html;
        divResultado.style.display = 'block';
        divResultado.scrollIntoView({ behavior: 'smooth' });
    }

    // Event listeners para atualização em tempo real
    document.addEventListener('DOMContentLoaded', function() {
        // Range do aumento
        document.getElementById('aumento_range').addEventListener('input', function() {
            document.getElementById('aumento_value').textContent = this.value + '%';
            document.getElementById('aumento_esperado').value = this.value;
            atualizarCalculosParciais();
        });

        // Outros campos que afetam cálculos
        ['alunos_atuais', 'mensalidade_media', 'horas_semanais'].forEach(id => {
            document.getElementById(id).addEventListener('input', atualizarCalculosParciais);
        });
    });
    </script>
    '''
    return get_base_html("Simulação - Business Plan", content)

@app.route('/calcular', methods=['POST'])
def calcular():
    try:
        dados = request.json
        
        # Validação
        if not dados.get('alunos_atuais') or dados['alunos_atuais'] <= 0:
            return jsonify({'error': 'Número de alunos atual inválido'}), 400
            
        if dados.get('aumento_esperado') < 30 or dados.get('aumento_esperado') > 50:
            return jsonify({'warning': 'Aumento esperado deve estar entre 30% e 50%'})
        
        # Calcular projeções
        resultados = calcular_projecao(dados)
        
        # Salvar na sessão
        session['ultima_simulacao'] = {
            'dados_entrada': dados,
            'resultados': resultados
        }
        
        # Salvar no banco de dados
        salvar_simulacao(dados, resultados)
        
        return jsonify(resultados)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/resultado')
def resultado():
    if 'ultima_simulacao' not in session:
        return index()
    
    dados = session['ultima_simulacao']
    resultados = dados['resultados']
    
    # Calcular distribuição de custos para gráfico
    custos_distribuicao = {
        'labels': ['Professores', 'Custos Fixos Nível', 'Infraestrutura', 'Material', 'Marketing'],
        'data': [
            resultados['custo_professores'],
            resultados['custos_fixos_total'],
            dados['dados_entrada'].get('custo_infraestrutura', 1000),
            dados['dados_entrada'].get('custo_material', 500),
            dados['dados_entrada'].get('custo_marketing', 800)
        ],
        'colors': ['#4361ee', resultados['cor_nivel'], '#FF6B8B', '#4ECDC4', '#96CEB4']
    }
    
    chart_js = f'''
    <script>
    document.addEventListener('DOMContentLoaded', function() {{
        // Gráfico de distribuição de custos
        const ctx1 = document.getElementById('chartCustos').getContext('2d');
        new Chart(ctx1, {{
            type: 'pie',
            data: {{
                labels: {json.dumps(custos_distribuicao['labels'])},
                datasets: [{{
                    data: {json.dumps(custos_distribuicao['data'])},
                    backgroundColor: {json.dumps(custos_distribuicao['colors'])},
                    borderWidth: 1
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{
                    legend: {{ position: 'bottom' }},
                    tooltip: {{
                        callbacks: {{
                            label: function(context) {{
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((context.parsed / total) * 100);
                                return context.label + ': R$ ' + context.parsed.toLocaleString('pt-BR') + 
                                       ' (' + percentage + '%)';
                            }}
                        }}
                    }}
                }}
            }}
        }});
        
        // Gráfico de receitas
        const ctx2 = document.getElementById('chartReceitas').getContext('2d');
        new Chart(ctx2, {{
            type: 'bar',
            data: {{
                labels: ['Receita Atual', 'Receita Projetada'],
                datasets: [{{
                    label: 'Valor em R$',
                    data: [{resultados['receita_atual']}, {resultados['receita_projetada']}],
                    backgroundColor: ['rgba(54, 162, 235, 0.5)', 'rgba(75, 192, 192, 0.5)'],
                    borderColor: ['rgba(54, 162, 235, 1)', 'rgba(75, 192, 192, 1)'],
                    borderWidth: 1
                }}]
            }},
            options: {{
                responsive: true,
                plugins: {{ legend: {{ display: false }} }},
                scales: {{
                    y: {{
                        beginAtZero: true,
                        ticks: {{
                            callback: function(value) {{
                                return 'R$ ' + value.toLocaleString('pt-BR');
                            }}
                        }}
                    }}
                }}
            }}
        }});
    }});
    </script>
    '''
    
    content = f'''
    <div class="row">
        <div class="col-lg-10 mx-auto">
            <div class="card shadow">
                <div class="card-header text-white" style="background-color: {resultados['cor_nivel']};">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="mb-0"><i class="fas fa-chart-pie"></i> Resultados da Simulação</h3>
                            <p class="mb-0">
                                <strong>{resultados['nome_nivel']}</strong> | 
                                Aumento: {dados['dados_entrada']['aumento_esperado']}% | 
                                ROI: {resultados['roi_percentual']:.1f}%
                            </p>
                        </div>
                        <span class="badge bg-light" style="color: {resultados['cor_nivel']};">
                            Payback: {resultados['payback_meses']:.1f} meses
                        </span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header bg-info text-white">
                                    <h5 class="mb-0"><i class="fas fa-chart-bar"></i> Comparativo de Receitas</h5>
                                </div>
                                <div class="card-body">
                                    <canvas id="chartReceitas" height="200"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header bg-success text-white">
                                    <h5 class="mb-0"><i class="fas fa-user-plus"></i> Crescimento</h5>
                                </div>
                                <div class="card-body text-center">
                                    <h1 class="display-1 text-primary">{resultados['novos_alunos']}</h1>
                                    <p class="lead">Novos Alunos</p>
                                    <div class="progress" style="height: 30px;">
                                        <div class="progress-bar bg-success" style="width: {dados['dados_entrada']['aumento_esperado']}%">
                                            {dados['dados_entrada']['aumento_esperado']}%
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header bg-warning text-dark">
                                    <h5 class="mb-0"><i class="fas fa-money-bill-wave"></i> Indicadores Financeiros</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row text-center">
                                        <div class="col-6">
                                            <div class="p-3 border rounded bg-light">
                                                <h6>Investimento Total</h6>
                                                <h3 class="text-primary">R$ {resultados['investimento_total']:,.0f}</h3>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-3 border rounded bg-light">
                                                <h6>Retorno Mensal</h6>
                                                <h3 class="text-success">R$ {resultados['retorno_mensal']:,.0f}</h3>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row mt-3 text-center">
                                        <div class="col-6">
                                            <div class="p-3 border rounded bg-light">
                                                <h6>Payback</h6>
                                                <h3>{resultados['payback_meses']:.1f} meses</h3>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-3 border rounded bg-light">
                                                <h6>ROI Anual</h6>
                                                <h3 class="text-success">{resultados['roi_percentual']:.1f}%</h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header bg-danger text-white">
                                    <h5 class="mb-0"><i class="fas fa-chart-pie"></i> Distribuição de Custos</h5>
                                </div>
                                <div class="card-body">
                                    <canvas id="chartCustos" height="200"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header bg-dark text-white">
                                    <h5 class="mb-0"><i class="fas fa-list-alt"></i> Detalhamento</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6><i class="fas fa-school"></i> Dados da Escola</h6>
                                            <table class="table table-sm">
                                                <tr><td>Alunos atuais:</td><td class="text-end">{dados['dados_entrada']['alunos_atuais']}</td></tr>
                                                <tr><td>Mensalidade média:</td><td class="text-end">R$ {dados['dados_entrada']['mensalidade_media']:,.2f}</td></tr>
                                                <tr><td>Aumento esperado:</td><td class="text-end">{dados['dados_entrada']['aumento_esperado']}%</td></tr>
                                                <tr><td>Nível escolar:</td><td class="text-end">{resultados['nome_nivel']}</td></tr>
                                            </table>
                                        </div>
                                        <div class="col-md-6">
                                            <h6><i class="fas fa-calculator"></i> Custos</h6>
                                            <table class="table table-sm">
    '''
    
    # Listar custos fixos do nível
    for custo in resultados.get('custos_fixos', []):
        content += f'<tr><td>{custo["nome"]}:</td><td class="text-end">R$ {custo["valor"]:,.2f}</td></tr>'
    
    content += f'''
                                                <tr><td>Infraestrutura:</td><td class="text-end">R$ {dados['dados_entrada'].get('custo_infraestrutura', 1000):,.2f}</td></tr>
                                                <tr><td>Material:</td><td class="text-end">R$ {dados['dados_entrada'].get('custo_material', 500):,.2f}</td></tr>
                                                <tr><td>Marketing:</td><td class="text-end">R$ {dados['dados_entrada'].get('custo_marketing', 800):,.2f}</td></tr>
                                                <tr><td>Professores ({resultados['professores_necessarios']}):</td><td class="text-end">R$ {resultados['custo_professores']:,.2f}/mês</td></tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header bg-success text-white">
                                    <h5 class="mb-0"><i class="fas fa-lightbulb"></i> Recomendações</h5>
                                </div>
                                <div class="card-body">
                                    <div class="alert {'alert-success' if resultados['roi_percentual'] > 100 else 'alert-warning'}">
                                        <h5>
                                            <i class="fas {'fa-check-circle' if resultados['roi_percentual'] > 100 else 'fa-exclamation-triangle'}"></i>
                                            Viabilidade: {'ALTA' if resultados['roi_percentual'] > 100 else 'MODERADA'}
                                        </h5>
                                        <p>
                                            Com ROI de {resultados['roi_percentual']:.1f}% e payback de {resultados['payback_meses']:.1f} meses,
                                            o projeto apresenta {'excelente viabilidade financeira' if resultados['roi_percentual'] > 100 else 'viabilidade financeira satisfatória'}.
                                        </p>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="card mb-3">
                                                <div class="card-body">
                                                    <h6><i class="fas fa-thumbs-up text-success"></i> Próximos Passos</h6>
                                                    <ul>
                                                        <li>Contratar {resultados['professores_necessarios']} professores especializados</li>
                                                        <li>Realizar adaptações na infraestrutura</li>
                                                        <li>Desenvolver material didático específico</li>
                                                        <li>Iniciar campanha de marketing</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="card mb-3">
                                                <div class="card-body">
                                                    <h6><i class="fas fa-chart-line text-info"></i> Monitoramento</h6>
                                                    <ul>
                                                        <li>Acompanhar taxa de adesão às atividades</li>
                                                        <li>Monitorar satisfação dos pais e alunos</li>
                                                        <li>Avaliar resultados acadêmicos</li>
                                                        <li>Revisar projeções trimestralmente</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="text-center mt-3">
                                        <a href="/simulacao" class="btn btn-primary btn-lg me-2">
                                            <i class="fas fa-redo"></i> Nova Simulação
                                        </a>
                                        <a href="/dashboard" class="btn btn-success btn-lg me-2">
                                            <i class="fas fa-tachometer-alt"></i> Dashboard
                                        </a>
                                        <button class="btn btn-info btn-lg" onclick="window.print()">
                                            <i class="fas fa-print"></i> Imprimir Relatório
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {chart_js}
    '''
    return get_base_html("Resultados - Business Plan", content)

@app.route('/dashboard')
def dashboard():
    simulacoes = buscar_simulacoes()
    
    # Preparar dados para tabela
    tabela_html = ""
    for s in simulacoes:
        dados = json.loads(s['dados']) if s['dados'] else {}
        resultados = dados.get('resultados', {})
        
        # Cor do badge baseada no nível
        nivel = s['nivel_escolar'] or 'fundamental_i'
        cor_nivel = CUSTOS_POR_NIVEL.get(nivel, {}).get('cor', '#6c757d')
        nome_nivel = CUSTOS_POR_NIVEL.get(nivel, {}).get('nome', 'Não especificado')
        
        tabela_html += f'''
        <tr>
            <td>{s['data_criacao'][:10]}</td>
            <td>{nome_nivel}</td>
            <td>{s['alunos_atuais']}</td>
            <td><span class="badge bg-success">{s['novos_alunos']}</span></td>
            <td><span class="badge bg-info">{s['aumento_esperado']}%</span></td>
            <td>R$ {s['investimento_total']:,.2f}</td>
            <td>
                <span class="badge {'bg-success' if s['roi'] > 100 else 'bg-warning'}">
                    {s['roi']:.1f}%
                </span>
            </td>
            <td>{s['payback']:.1f} meses</td>
            <td>
                <a href="#" class="btn btn-sm btn-primary" onclick="verSimulacao({s['id']})">
                    <i class="fas fa-eye"></i> Ver
                </a>
            </td>
        </tr>
        '''
    
    if not simulacoes:
        tabela_html = '''
        <tr>
            <td colspan="9" class="text-center py-5">
                <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                <h4>Nenhuma simulação encontrada</h4>
                <p>Realize sua primeira simulação para começar</p>
                <a href="/simulacao" class="btn btn-primary">
                    <i class="fas fa-plus-circle"></i> Nova Simulação
                </a>
            </td>
        </tr>
        '''
    
    content = f'''
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0"><i class="fas fa-tachometer-alt"></i> Dashboard</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Data</th>
                                    <th>Nível</th>
                                    <th>Alunos</th>
                                    <th>Novos</th>
                                    <th>Aumento</th>
                                    <th>Investimento</th>
                                    <th>ROI</th>
                                    <th>Payback</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                {tabela_html}
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="/simulacao" class="btn btn-primary btn-lg">
                            <i class="fas fa-plus-circle"></i> Nova Simulação
                        </a>
                        <a href="/" class="btn btn-secondary btn-lg ms-2">
                            <i class="fas fa-home"></i> Página Inicial
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function verSimulacao(id) {{
        window.location.href = '/simulacao/' + id;
    }}
    </script>
    '''
    return get_base_html("Dashboard - Business Plan", content)

@app.route('/simulacao/<int:id>')
def ver_simulacao_detalhes(id):
    # Buscar simulação específica
    try:
        conn = sqlite3.connect(DATABASE)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM simulacoes WHERE id = ?', (id,))
        simulacao = cursor.fetchone()
        conn.close()
        
        if simulacao:
            dados = json.loads(simulacao['dados']) if simulacao['dados'] else {}
            session['ultima_simulacao'] = dados
            return redirect('/resultado')
    except:
        pass
    
    return redirect('/')

if __name__ == '__main__':
    if init_db():
        print("=" * 60)
        print("🚀 BUSINESS PLAN ESCOLAR - SIMPLIFICADO")
        print("=" * 60)
        print("✅ Todos os campos editáveis")
        print("✅ Interface passo a passo")
        print("✅ Cálculos automáticos")
        print("✅ Salva automaticamente")
        print("=" * 60)
        
        port = int(os.environ.get('PORT', 5000))
        debug = os.environ.get('FLASK_ENV') != 'production'
        
        if debug:
            print(f"🌐 Acesse: http://localhost:{port}")
        
        app.run(
            debug=debug,
            port=port,
            host='0.0.0.0',
            threaded=True
        )
    else:
        print("❌ Não foi possível inicializar o sistema.")